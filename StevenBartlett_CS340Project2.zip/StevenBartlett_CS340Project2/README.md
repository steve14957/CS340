## CS-340 Project Two: Grazioso Salvare Rescue Animal Dashboard

## Project Description

This project was developed for Grazioso Salvare, an organization that trains rescue dogs for search-and-rescue operations. The purpose of the project is to create an interactive web-based dashboard that allows users to search, filter, and visualize animal shelter data stored in a MongoDB database.

The dashboard builds upon the CRUD (Create, Read, Update, Delete) Python module developed in Project One. This module provides the connection between the dashboard and MongoDB, allowing the application to retrieve animal records based on specific search-and-rescue requirements.

The dashboard was developed using Python and the Dash framework within a Jupyter Notebook environment. It provides interactive filtering options for water rescue, mountain or wilderness rescue, and disaster or individual tracking. Users can view matching animals in a data table, examine breed distributions through a pie chart, and view the geographic location of a selected animal on an interactive map.

The overall goal of the application is to make animal shelter information easier to access and analyze, helping Grazioso Salvare identify potential candidates for specialized rescue training.

## Dashboard Functionality

The Grazioso Salvare dashboard provides several interactive features that allow users to retrieve, filter, and visualize animal shelter records.

## Rescue Type Filtering

The dashboard includes four radio-button filtering options:

* **Reset:** Displays all available animal records without applying rescue-specific restrictions.
* **Water Rescue:** Filters dogs by qualifying breeds, intact female status, and an age range of 26 to 156 weeks.
* **Mountain or Wilderness Rescue:** Filters dogs by qualifying breeds, intact male status, and an age range of 26 to 156 weeks.
* **Disaster or Individual Tracking:** Filters dogs by qualifying breeds, intact male status, and an age range of 20 to 300 weeks.

Each option generates a MongoDB query using the CRUD Python module developed in Project One. Selecting a different filter updates the records displayed in the dashboard.

##Interactive Data Table

The dashboard includes an interactive data table that displays animal shelter records retrieved from MongoDB.

The table responds to the selected rescue filter, allowing users to review animals that meet the specified requirements. Users can also select individual animal records to examine their geographic locations.

##Breed Distribution Pie Chart

A Plotly pie chart displays the distribution of animal breeds in the currently filtered data.

The chart updates automatically when the data table changes. To improve readability, the chart displays the ten most common breeds individually and combines the remaining breeds into an "Other Breeds" category.

This visualization helps users identify the breeds most frequently represented within the selected rescue category.

## Interactive Geographic Map

The dashboard uses Dash Leaflet to display the geographic location associated with a selected animal record.

When a user selects an animal in the data table, the map updates its center and marker position using the latitude and longitude stored in MongoDB.

The map marker provides additional animal information, including the animal's name and breed.

Together, these dashboard features allow Grazioso Salvare to explore shelter records and identify potential search-and-rescue candidates more efficiently.

## Tools and Technologies

The Grazioso Salvare Rescue Animal Dashboard was developed using several technologies that work together to retrieve, process, display, and visualize animal shelter data.

## Python

Python serves as the primary programming language for the application. It was selected because of its readability, extensive library support, and ability to integrate database operations with interactive web applications.

## ##MongoDB

MongoDB is the NoSQL database used to store animal shelter records. It was selected because its document-based structure supports flexible data storage and allows records to be retrieved using queries involving animal breeds, ages, and other characteristics.

MongoDB query operators such as `$in`, `$gte`, and `$lte` allow the dashboard to identify animals meeting specific search-and-rescue requirements.

## CRUD Python Module

The CRUD Python module developed in Project One provides reusable database access functionality.

The dashboard uses the module's `read()` method to retrieve animal records from MongoDB. Reusing this module separates database operations from the dashboard interface, making the application easier to maintain and expand.

## Dash

Dash is the Python web application framework used to create the interactive dashboard.

It was selected because it supports web-based interfaces using Python without requiring extensive JavaScript development. Dash callbacks connect the rescue filters, data table, pie chart, and map, allowing the dashboard to respond to user interactions.

## Pandas

Pandas is used to convert MongoDB query results into DataFrames for processing and display.

It was selected because it provides convenient methods for organizing records, counting animal breeds, and converting filtered data into the format required by the dashboard.

## Plotly Express

Plotly Express is used to create the interactive breed distribution pie chart.

It was selected because it integrates directly with Dash and provides interactive visualizations, including percentage labels and hover information. The chart helps users understand the distribution of animal breeds within the selected rescue category.

## Dash Leaflet

Dash Leaflet is used to display animal locations on an interactive geographic map.

It was selected because it integrates with Dash and supports map tiles, markers, tooltips, and popups. The map uses latitude and longitude values from the animal records to display the selected animal's location.

## Jupyter Notebook and Codio

Jupyter Notebook provides the development environment for writing, executing, and testing the Python dashboard code. Codio provides the cloud-based workspace used for the project.

These tools were used because they support iterative development, allowing individual code cells to be executed and tested while building the dashboard.

## Steps to Reproduce the Project

The following steps describe how to set up and run the Grazioso Salvare Rescue Animal Dashboard.

## Step 1: Prepare the Development Environment

Open a Python development environment that supports Jupyter Notebook, such as the Codio environment used for this project.

Ensure Python and Jupyter Notebook are available and install the required libraries if they are not already installed:

* `pandas`
* `pymongo`
* `dash`
* `plotly`
* `dash-leaflet`

The environment must also have access to a running MongoDB database.

## Step 2: Prepare the MongoDB Database

Set up a MongoDB database containing the animal shelter records used by the application.

The records must include the fields required by the dashboard, including:

* Animal type
* Breed
* Sex upon outcome
* Age upon outcome in weeks
* Animal name
* Latitude and longitude

Import the animal shelter dataset into MongoDB if the records are not already available.

Configure database access permissions so the application can retrieve records from the appropriate database and collection.

## Step 3: Configure the CRUD Python Module

Place the CRUD Python module developed in Project One in the same project directory as the dashboard notebook, or ensure that it is available through the Python import path.

Configure the module to connect to the appropriate MongoDB database using valid credentials.

The dashboard uses the module's `read()` method to execute MongoDB queries and retrieve matching animal records.

For security, database passwords should not be included in the README or shared publicly.

## Step 4: Open the Dashboard Notebook

Open `ProjectTwoDashboard.ipynb` in Jupyter Notebook.

Verify that the required libraries and CRUD module are imported correctly.

Run the notebook cells in order to initialize the database connection, construct the dashboard layout, register the callbacks, and start the Dash application.

## Step 5: Test the Rescue Filters

Once the dashboard is running, test each radio-button option:

1. Select Reset to display all available animal records.
2. Select Water Rescue to display animals meeting the water rescue requirements.
3. Select Mountain or Wilderness Rescue to display animals meeting the wilderness rescue requirements.
4. Select Disaster or Individual Tracking to display animals meeting the disaster tracking requirements.

Confirm that the data table updates when each option is selected.

## Step 6: Test the Data Visualizations

Verify that the breed distribution pie chart updates when the rescue filter changes.

The chart should display the ten most common breeds and combine the remaining breeds into an Other Breeds category.

Select an animal record in the data table and verify that the map updates to display its geographic location.

Click the map marker to view the available animal information.

## Step 7: Verify the Completed Dashboard

Confirm that the filtering options, data table, pie chart, and map function together correctly.

Capture screenshots demonstrating the dashboard's functionality, including the required unique identifier, for submission with the project.

##  Challenges and Solutions

Several challenges were encountered while developing the Grazioso Salvare Rescue Animal Dashboard. These challenges involved integrating MongoDB with the dashboard, configuring interactive components, resolving Python errors, and improving data visualization.

## Python Syntax and Indentation Errors

One challenge involved Python indentation errors while implementing and modifying the Dash callback functions.

Because Python uses indentation to define code blocks, incorrectly aligned statements prevented the notebook from executing successfully.

These issues were resolved by reviewing the affected functions, correcting indentation levels, and ensuring that statements within each function followed a consistent structure.

## Dash Callback Configuration

Another challenge involved configuring Dash callbacks to update dashboard components when users interacted with the application.

The rescue filters needed to update the data table, while the pie chart and map needed to respond to changes in the displayed records.

This was resolved by connecting Dash input and output components through callbacks. The filtering callback retrieves matching records from MongoDB, while separate callbacks update the chart and map based on the data table.

## Interactive Map Display

The geographic map required additional adjustments to display correctly and respond to animal selections.

The solution involved configuring the Dash Leaflet map with appropriate dimensions and using the selected animal's latitude and longitude to update the map center and marker position.

Additional information was included in marker tooltips and popups to help users identify the selected animal.

## Pie Chart Readability

The original breed distribution pie chart contained too many individual breed categories, making the chart difficult to read when displaying all animal records.

To resolve this issue, the chart was modified to display the ten most common breeds individually while combining the remaining breeds into an Other Breeds category.

This improved the chart's readability while preserving the overall distribution of the displayed animal records.

## Testing Dashboard Interactions

An additional challenge involved ensuring that the filtering controls, data table, pie chart, and geographic map worked together.

Each dashboard component was tested by selecting different rescue filters, examining the resulting records, and selecting animals in the data table.

These tests helped confirm that the dashboard responded correctly to user input and that the visualizations reflected the selected data.

## Lessons Learned

This project reinforced the importance of testing individual application components before integrating them into a larger system.

It also demonstrated how reusable database modules, callback-driven interfaces, and interactive visualizations can work together to create an application that supports data-driven decisions.

Troubleshooting syntax errors, refining callback functions, and improving visual presentation provided valuable experience in developing and debugging Python applications.

## Screenshots

The following screenshots demonstrate the completed Grazioso Salvare Rescue Animal Dashboard and its interactive functionality.

## Screenshot 1: Dashboard – Reset Filter

![Reset Filter - Data Table](screenshots/dashboard_reset1.png)

![Reset Filter - Pie Chart and Map](screenshots/dashboard_reset2.png)



This screenshot demonstrates the dashboard with the Reset filter selected. The interactive data table displays available animal records, and the breed distribution pie chart summarizes the displayed data.



## Screenshot 2: Water Rescue Filter

![Water Rescue - Data Table](screenshots/dashboard_water1.png)

![Water Rescue - Pie Chart and Map](screenshots/dashboard_water2.png)

This screenshot demonstrates the Water Rescue filter and the resulting animal records. The data table and breed distribution pie chart update to reflect animals meeting the water rescue requirements.

## Screenshot 3: Mountain or Wilderness Rescue Filter

![Mountain or Wilderness Rescue Dashboard](screenshots/dashboard_mountainwilderness.png)

This screenshot demonstrates the Mountain or Wilderness Rescue filter and the corresponding results displayed in the interactive data table.

## Screenshot 4: Disaster or Individual Tracking Filter

![Disaster or Individual Tracking Dashboard](screenshots/dashboard_DisasterIndividualTracking.png)

This screenshot demonstrates the Disaster or Individual Tracking filter and the corresponding animal records.


